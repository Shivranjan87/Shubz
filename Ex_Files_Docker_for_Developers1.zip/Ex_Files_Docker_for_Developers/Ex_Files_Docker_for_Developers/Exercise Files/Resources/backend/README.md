# node-mongo-docker
A node and express docker template with Mongo
